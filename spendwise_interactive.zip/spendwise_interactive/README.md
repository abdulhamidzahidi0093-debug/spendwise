# SpendWise — Make It Interactive

## About the project

SpendWise is a simple personal budgeting application. This week's update makes the page interactive: a user can set a monthly budget, add expenses, remove expenses, and see the budget summary update automatically.

## What was improved this week?

- Added a form for setting or updating the monthly budget.
- Added an expense form with a description, category, amount, and date.
- Added a recent-expenses list with a Delete button for each record and a Clear All option.
- Added dashboard cards for the monthly budget, total spent, and money remaining.
- Added a progress bar and messages that explain whether spending is within the budget, close to the budget, or over budget.
- Saved the budget and expense records in the browser's local storage so they remain after the page is refreshed in the same browser.

## How conditionals are used

The project uses `if`, `else if`, and `else` to check whether the user entered valid information and to decide what budget message to show. For example, SpendWise displays a warning when spending is over the budget and a different message when 80% or more of the budget has been used. It also checks that expense amounts and the budget are greater than zero.

## How arrays are used

The `expenses` array stores multiple expense records. When the user adds an expense, the program uses `push()` to add a new record. When an expense is deleted, the program uses `filter()` to create an array without that record. The array is also saved in browser local storage as JSON.

## How the DOM is updated

The JavaScript selects page elements using `document.getElementById()`. It changes dashboard text with `textContent`, updates the progress bar, and creates expense-list elements with `document.createElement()` and `appendChild()`. The expense list and summary are redrawn whenever the data changes.

## How user interactions are handled

The project uses `addEventListener()` to respond to form submissions and button clicks. Submitting the budget form updates the budget. Submitting the expense form adds an expense. Clicking Delete removes one expense, and clicking Clear All asks for confirmation before removing all expenses.

## How to run the project

1. Keep `index.html`, `style.css`, and `script.js` in the same folder.
2. Open `index.html` in a web browser.
3. Set a monthly budget, then add a few expenses to see the dashboard update.

No extra packages or installation are required.

## Challenges and how they were resolved

One challenge was keeping the dashboard totals and the expense list in sync after an expense was added or removed. I handled this by using one `renderApp()` function to refresh the dashboard and the list after each change. Another challenge was checking invalid input, so I added conditionals that ask the user to enter a valid description, date, and positive amount instead of saving incorrect records.
