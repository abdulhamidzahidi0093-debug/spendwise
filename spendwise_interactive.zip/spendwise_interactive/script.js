// SpendWise: interactive personal budget tracker.
// Expenses are kept in an array and saved in this browser between visits.

const DEFAULT_BUDGET = 30000;
const EXPENSES_STORAGE_KEY = "spendwise_expenses_v1";
const BUDGET_STORAGE_KEY = "spendwise_budget_v1";

const budgetAmountElement = document.getElementById("budgetAmount");
const totalSpentElement = document.getElementById("totalSpent");
const remainingAmountElement = document.getElementById("remainingAmount");
const budgetMessageElement = document.getElementById("budgetMessage");
const progressLabelElement = document.getElementById("progressLabel");
const progressTrackElement = document.getElementById("progressTrack");
const budgetProgressElement = document.getElementById("budgetProgress");
const budgetForm = document.getElementById("budgetForm");
const monthlyBudgetInput = document.getElementById("monthlyBudget");
const budgetFormMessage = document.getElementById("budgetFormMessage");
const expenseForm = document.getElementById("expenseForm");
const descriptionInput = document.getElementById("description");
const categoryInput = document.getElementById("category");
const amountInput = document.getElementById("amount");
const expenseDateInput = document.getElementById("expenseDate");
const expenseFormMessage = document.getElementById("expenseFormMessage");
const expenseListElement = document.getElementById("expenseList");
const emptyStateElement = document.getElementById("emptyState");
const expenseCountElement = document.getElementById("expenseCount");
const clearExpensesButton = document.getElementById("clearExpenses");

// Load saved expenses. If browser storage is unavailable or empty, use an empty list.
function loadExpenses() {
    try {
        const savedExpenses = JSON.parse(localStorage.getItem(EXPENSES_STORAGE_KEY));
        return Array.isArray(savedExpenses) ? savedExpenses : [];
    } catch (error) {
        return [];
    }
}

// Load a saved budget or use the starter budget.
function loadBudget() {
    try {
        const savedBudget = Number(localStorage.getItem(BUDGET_STORAGE_KEY));
        if (Number.isFinite(savedBudget) && savedBudget > 0) {
            return savedBudget;
        }
    } catch (error) {
        // Use the default budget if browser storage cannot be read.
    }
    return DEFAULT_BUDGET;
}

let expenses = loadExpenses();
let monthlyBudget = loadBudget();

// Save the current data so it is still here when the page is reopened.
function saveData() {
    try {
        localStorage.setItem(EXPENSES_STORAGE_KEY, JSON.stringify(expenses));
        localStorage.setItem(BUDGET_STORAGE_KEY, String(monthlyBudget));
    } catch (error) {
        // The app can still work for this visit if browser storage is unavailable.
        console.warn("SpendWise could not save data in this browser.", error);
    }
}

// Format amounts as Kenyan shillings.
function formatMoney(amount) {
    return new Intl.NumberFormat("en-KE", {
        style: "currency",
        currency: "KES",
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(amount);
}

// Calculate the total by looping through every saved expense.
function calculateTotalSpent() {
    let total = 0;

    for (const expense of expenses) {
        total += expense.amount;
    }

    return total;
}

// Update the summary cards and budget feedback on the page.
function renderDashboard() {
    const totalSpent = calculateTotalSpent();
    const remaining = monthlyBudget - totalSpent;
    const percentageUsed = (totalSpent / monthlyBudget) * 100;
    const safePercentage = Math.min(Math.max(percentageUsed, 0), 100);

    budgetAmountElement.textContent = formatMoney(monthlyBudget);
    totalSpentElement.textContent = formatMoney(totalSpent);
    remainingAmountElement.textContent = formatMoney(remaining);
    progressLabelElement.textContent = `${percentageUsed.toFixed(1)}% used`;
    budgetProgressElement.style.width = `${safePercentage}%`;
    progressTrackElement.setAttribute("aria-valuenow", String(Math.round(safePercentage)));

    // Conditional statements give the user feedback about their spending.
    if (totalSpent > monthlyBudget) {
        const overBy = totalSpent - monthlyBudget;
        budgetMessageElement.textContent = `You are over budget by ${formatMoney(overBy)}. Review your spending.`;
        budgetMessageElement.style.color = "#b33a37";
        budgetProgressElement.classList.add("over-budget");
    } else if (totalSpent >= monthlyBudget * 0.8) {
        budgetMessageElement.textContent = "You have used at least 80% of your budget. Spend carefully.";
        budgetMessageElement.style.color = "#9b6412";
        budgetProgressElement.classList.remove("over-budget");
    } else {
        budgetMessageElement.textContent = "You are within your budget. Keep it up!";
        budgetMessageElement.style.color = "#687977";
        budgetProgressElement.classList.remove("over-budget");
    }
}

// Display every expense in the HTML list using DOM elements and a loop.
function renderExpenses() {
    expenseListElement.replaceChildren();
    emptyStateElement.hidden = expenses.length > 0;

    if (expenses.length === 1) {
        expenseCountElement.textContent = "1 expense recorded";
    } else {
        expenseCountElement.textContent = `${expenses.length} expenses recorded`;
    }

    // Show the newest expense first without changing the original array order.
    const newestFirst = [...expenses].reverse();

    for (const expense of newestFirst) {
        const item = document.createElement("li");
        item.className = "expense-item";

        const details = document.createElement("div");
        details.className = "expense-details";

        const title = document.createElement("span");
        title.className = "expense-title";
        title.textContent = expense.description;

        const meta = document.createElement("span");
        meta.className = "expense-meta";
        meta.textContent = `${expense.category} · ${formatDate(expense.date)}`;

        details.append(title, meta);

        const actions = document.createElement("div");
        actions.className = "expense-actions";

        const amount = document.createElement("span");
        amount.className = "expense-amount";
        amount.textContent = formatMoney(expense.amount);

        const deleteButton = document.createElement("button");
        deleteButton.type = "button";
        deleteButton.className = "delete-button";
        deleteButton.textContent = "Delete";
        deleteButton.setAttribute("aria-label", `Delete expense: ${expense.description}`);

        // Event listener lets the user remove this expense.
        deleteButton.addEventListener("click", () => {
            expenses = expenses.filter((itemToKeep) => itemToKeep.id !== expense.id);
            saveData();
            renderApp();
        });

        actions.append(amount, deleteButton);
        item.append(details, actions);
        expenseListElement.appendChild(item);
    }
}

// Convert the saved date into a readable date for the expense list.
function formatDate(dateString) {
    const date = new Date(`${dateString}T00:00:00`);
    if (Number.isNaN(date.getTime())) {
        return dateString;
    }

    return date.toLocaleDateString("en-KE", {
        day: "numeric",
        month: "short",
        year: "numeric"
    });
}

// Refresh all visible parts of the application after data changes.
function renderApp() {
    renderDashboard();
    renderExpenses();
}

// Handle the budget form submission.
budgetForm.addEventListener("submit", (event) => {
    event.preventDefault();

    const newBudget = Number(monthlyBudgetInput.value);

    if (!Number.isFinite(newBudget) || newBudget <= 0) {
        budgetFormMessage.textContent = "Please enter a budget greater than zero.";
        return;
    }

    monthlyBudget = newBudget;
    saveData();
    renderDashboard();
    budgetFormMessage.textContent = "Your monthly budget has been updated.";
});

// Handle adding a new expense to the expenses array.
expenseForm.addEventListener("submit", (event) => {
    event.preventDefault();

    const description = descriptionInput.value.trim();
    const amount = Number(amountInput.value);
    const date = expenseDateInput.value;

    if (description === "") {
        expenseFormMessage.textContent = "Please enter a description.";
        descriptionInput.focus();
        return;
    }

    if (!Number.isFinite(amount) || amount <= 0) {
        expenseFormMessage.textContent = "Please enter an amount greater than zero.";
        amountInput.focus();
        return;
    }

    if (date === "") {
        expenseFormMessage.textContent = "Please choose a date.";
        expenseDateInput.focus();
        return;
    }

    // Add the new record to the array.
    expenses.push({
        id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
        description,
        category: categoryInput.value,
        amount,
        date
    });

    saveData();
    renderApp();
    expenseForm.reset();
    expenseDateInput.value = new Date().toISOString().slice(0, 10);
    expenseFormMessage.textContent = "Expense added successfully.";
});

// Handle the Clear All button.
clearExpensesButton.addEventListener("click", () => {
    if (expenses.length === 0) {
        expenseFormMessage.textContent = "There are no expenses to clear.";
        return;
    }

    const confirmed = window.confirm("Are you sure you want to delete all expenses?");
    if (confirmed) {
        expenses = [];
        saveData();
        renderApp();
        expenseFormMessage.textContent = "All expenses have been cleared.";
    }
});

// Set useful starting values and show saved data when the page opens.
monthlyBudgetInput.value = String(monthlyBudget);
expenseDateInput.value = new Date().toISOString().slice(0, 10);
renderApp();
